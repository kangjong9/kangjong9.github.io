"""검증되지 않은 발음 점수를 반환하지 않는 독립 평가 계약."""
def assess():
    return {'status':'unsupported','reject_reason':'unvalidated','validated':False,
            'pronunciation_assessment':None,'required_evidence':'expert-labelled held-out pronunciation corpus and calibrated scoring model'}
