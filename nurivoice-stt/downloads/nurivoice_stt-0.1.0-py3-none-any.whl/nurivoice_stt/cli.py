import argparse
import json
from .api import recognize
def main():
    import sys
    if hasattr(sys.stdout,'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
    p=argparse.ArgumentParser()
    p.add_argument('task',choices=['transcribe','phoneme','assessment','streaming'])
    inputs=p.add_mutually_exclusive_group(required=True)
    inputs.add_argument('--input')
    inputs.add_argument('--mic',action='store_true',help='명시 실행 시 5초 녹음')
    p.add_argument('--language','--l2',default='en')
    p.add_argument('--l1'); p.add_argument('--locale'); p.add_argument('--target')
    p.add_argument('--model',choices=['tiny','base','auto'],default='tiny')
    p.add_argument('--device-profile',choices=['balanced','low_memory','quality'],default='balanced')
    p.add_argument('--vad',action='store_true',help='Silero 음성 구간 검출 (음소 정확도 미검증)')
    p.add_argument('--trim',action='store_true',help='--vad와 함께 앞뒤 무음만 제거')
    a=p.parse_args()
    result=recognize(a.input,a.task,a.language,a.locale,a.l1,a.target,a.model,mic=a.mic,vad=a.vad,trim=a.trim,device_profile=a.device_profile)
    print(json.dumps(result,ensure_ascii=False))
    return 1 if result['status']=='error' else 0
if __name__=='__main__': raise SystemExit(main())
