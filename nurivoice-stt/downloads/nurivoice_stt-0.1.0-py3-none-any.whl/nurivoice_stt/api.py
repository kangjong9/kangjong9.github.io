import hashlib
import time
from . import adapters
from .capture import read_wav
from .quality import inspect_audio
from .phoneme import decide
from .registry import LANGUAGES, LOCALES, MODELS

def recognize(path,task='transcribe',language='en',locale=None,l1=None,target=None,model='tiny',mic=False,vad=False,trim=False,device_profile='balanced'):
    started=time.perf_counter()
    requested_model=model
    result=dict(status='error',task=task,transcript=None,phone_hypotheses=[],target_phone=target,
                phone_match=None,reject_reason=None,language=language,locale=locale,l1=l1,
                model_id=None,model_revision=None,runtime_ms=0,score_type='unscored',validated=False)
    try:
        if mic and path is not None: raise ValueError('파일 입력과 마이크를 동시에 지정할 수 없습니다.')
        if locale is not None and (locale not in LOCALES or (language!='auto' and ('no' if locale.startswith('nb-') else locale.split('-')[0]) != language)):
            result.update(status='unsupported',reject_reason='unsupported_locale'); return result
        if task=='assessment':
            from .assessment import assess
            result.update(assess()); return result
        if (language not in LANGUAGES and not (language=='auto' and task=='transcribe')) or task not in {'transcribe','phoneme','streaming'} or model not in {'tiny','base','auto'}:
            result.update(status='unsupported',reject_reason='unsupported_configuration'); return result
        if task=='streaming' and language!='fr':
            result.update(status='unsupported',reject_reason='streaming_language_unsupported'); return result
        from .router import route
        result['route']=route(task,'en' if language=='auto' else language,model,device_profile)
        if task=='transcribe': model=result['route']['model']
        if task=='phoneme':
            status,reason,_=decide([],language,target,l1)
            if status=='unsupported': result.update(status=status,reject_reason=reason); return result
        if mic and task=='streaming':
            if vad or trim: raise ValueError('라이브 스트리밍은 자체 endpoint를 사용합니다. vad/trim은 파일 입력용입니다.')
            from .streaming import FrenchStreaming
            events=list(FrenchStreaming().stream_microphone(consent=True))
            result.update(events[-1]); result['partial_results']=events[:-1]
            result.update(locale=locale,l1=l1,target_phone=target)
            return result
        if path is None:
            if not mic: raise ValueError('입력 WAV 또는 명시적인 mic=True가 필요합니다.')
            from .capture import record_microphone
            x=record_microphone(consent=True)
        else:
            x=read_wav(path)
        reject=inspect_audio(x)
        if reject: result.update(status='rejected',reject_reason=reject); return result
        if language=='auto':
            from .registry import verify_models
            verify_models(model)
            language=adapters.identify_language(x,model)
            result.update(language=language,language_detection={'model':model,'timing':adapters.metrics(),'validated':False})
            if language not in LANGUAGES and requested_model=='auto' and model=='tiny' and device_profile!='low_memory':
                first=result['language_detection'].copy()
                first['language']=language
                verify_models('base')
                language=adapters.identify_language(x,'base')
                model='base'
                result['route']=route(task,language if language in LANGUAGES else 'en','base',device_profile)
                result['route']['reason']='auto policy: unsupported tiny language; retry base'
                result.update(language=language,language_detection={'model':'base','timing':adapters.metrics(),'validated':False,'previous_attempt':first})
            if language not in LANGUAGES:
                result.update(status='unsupported',reject_reason='detected_language_unsupported'); return result
            if locale is not None and ('no' if locale.startswith('nb-') else locale.split('-')[0])!=language:
                result.update(status='unsupported',reject_reason='detected_language_locale_mismatch'); return result
        if trim and not vad: raise ValueError('trim에는 vad=True가 필요합니다.')
        if vad:
            from .vad import speech_segments
            vad_start=time.perf_counter()
            segments=speech_segments(x)
            result['vad']={'segments':segments,'elapsed_ms':(time.perf_counter()-vad_start)*1000,'trim':trim,'validated_for_isolated_phones':False}
            if not segments:
                result.update(status='rejected',reject_reason='no_speech_detected'); return result
            if trim:
                # Keep interior pauses; only trim leading/trailing regions with padding.
                start,end=segments[0]['start'],segments[-1]['end']
                result['vad']['removed_samples']=len(x)-(end-start)
                x=x[start:end]
        if task=='streaming':
            from .streaming import FrenchStreaming
            stream=FrenchStreaming()
            events=list(stream.stream(x,language=language))
            result.update(events[-1]);result['partial_results']=events[:-1]
            result.update(locale=locale,l1=l1,target_phone=target)
            return result
        result['model_id']=f'whisper-{model}-int8' if task=='transcribe' else 'xlsr53-student-q4'
        from .registry import verify_models
        verify_start=time.perf_counter()
        verify_models(model if task=='transcribe' else 'phoneme')
        result['integrity_ms']=(time.perf_counter()-verify_start)*1000
        artifact=MODELS/(f'whisper-{model}-encoder.onnx' if task=='transcribe' else 'phoneme.onnx')
        result['model_revision']='sha256:'+hashlib.sha256(artifact.read_bytes()).hexdigest()
        if task=='transcribe':
            text=adapters.transcribe(x,language,model)
            result.update(status='recognized' if text.strip() else 'unknown',transcript=text)
        else:
            phones=adapters.phones(x)
            status,reason,competitors=decide(phones,language,target,l1)
            result.update(status=status,reject_reason=reason,phone_hypotheses=phones,competitors=competitors)
            result['candidate_evidence']=adapters.phone_evidence(target,competitors)
        result['timing']=adapters.metrics()
    except Exception as exc:
        result.update(status='error',reject_reason='input_or_runtime_error',error=str(exc))
    finally:
        result['runtime_ms']=(time.perf_counter()-started)*1000
        from .resources import process_memory
        result['resources']=process_memory()
    return result
