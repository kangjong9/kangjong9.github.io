"""명시적 task/device 정책. 작은 평가셋으로 최적 정확도를 주장하지 않는다."""
from .registry import LANGUAGES

def route(task: str, language: str, model: str='tiny', device_profile: str='balanced') -> dict:
    if device_profile not in {'balanced','low_memory','quality'}:
        raise ValueError('unsupported device profile')
    if language not in LANGUAGES:
        raise ValueError('unsupported language')
    if task=='assessment': return {'adapter':'assessment','model':None,'reason':'requires calibrated expert evidence'}
    if task=='phoneme': return {'adapter':'phoneme','model':'student-q4','reason':'task-specific CTC observations'}
    if task=='streaming':
        if language!='fr': raise ValueError('streaming language unsupported')
        return {'adapter':'zipformer','model':'zipformer-fr-int8','reason':'online transducer capability'}
    if task!='transcribe' or model not in {'tiny','base','auto'}: raise ValueError('unsupported task/model')
    selected=('base' if device_profile=='quality' else 'tiny') if model=='auto' else model
    return {'adapter':'whisper','model':selected,'reason':'explicit selection' if model!='auto' else 'resource policy; not accuracy guarantee'}
