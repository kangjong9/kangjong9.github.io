INVENTORIES = {'fr': {'a','i','u','ɛ','e','o','ɔ','y','ø','œ','ɑ','ə','ɛ̃','ɑ̃','ɔ̃','œ̃'}}
def decide(phones, language, target, l1=None):
    inventory = INVENTORIES.get(language)
    if inventory is None or target not in inventory:
        return 'unsupported', 'unsupported_target', []
    competitors = sorted(inventory - {target})
    # L1 is an unvalidated contrast hint; never alters the match score.
    if l1 == 'ko' and target in {'u','y'}:
        competitors = sorted(set(competitors)|{'ɯ','ɨ'})
    if not phones: return 'unknown','uncertain',competitors
    if len(phones)!=1: return 'rejected','other_phone',competitors
    if phones[0] != target:
        return 'rejected', ('other_phone' if phones[0] in inventory or phones[0] in competitors else 'unknown_phone'), competitors
    return 'recognized',None,competitors
