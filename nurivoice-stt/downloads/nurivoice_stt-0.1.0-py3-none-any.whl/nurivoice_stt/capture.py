"""로컬 WAV 정규화 및 명시적 호출에만 시작하는 Windows 마이크 입력."""
from __future__ import annotations

import ctypes
import math
import sys
import time
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

SAMPLE_RATE = 16000
MAX_SECONDS = 120


def read_wav(path: str | Path) -> np.ndarray:
    """WAV를 16kHz mono float32로 변환. 빈 입력/과대 입력/비유한 값 거부."""
    with sf.SoundFile(str(path)) as stream:
        if stream.format not in {"WAV", "WAVEX", "RF64"}:
            raise ValueError("WAV 파일만 지원합니다.")
        if not 8000 <= stream.samplerate <= 192000 or not 1 <= stream.channels <= 8:
            raise ValueError("지원하지 않는 샘플레이트/채널 수입니다.")
        if stream.frames < 1 or stream.frames / stream.samplerate > MAX_SECONDS:
            raise ValueError("입력은 비어 있지 않은 최대 120초 WAV여야 합니다.")
        rate = stream.samplerate
        audio = stream.read(dtype="float32", always_2d=True)
    if not np.isfinite(audio).all():
        raise ValueError("입력에 NaN/Infinity가 있습니다.")
    if np.max(np.abs(audio)) > 1.0001:
        raise ValueError("입력 PCM 진폭이 [-1, 1] 범위를 벗어났습니다.")
    mono = audio.mean(axis=1)
    if rate != SAMPLE_RATE:
        divisor = math.gcd(rate, SAMPLE_RATE)
        mono = resample_poly(mono, SAMPLE_RATE // divisor, rate // divisor)
    return np.ascontiguousarray(mono, dtype=np.float32)


def microphone_diagnostics() -> dict:
    """장치 수만 조회하며 마이크를 열거나 녹음하지 않는다."""
    if sys.platform != "win32":
        return {"available": False, "reason": "Windows WinMM 입력만 구현됨", "fallback": "--input audio.wav"}
    count = int(ctypes.WinDLL("winmm").waveInGetNumDevs())
    return {"available": count > 0, "device_count": count, "backend": "Windows WinMM", "recording_started": False,
            "note": "장치 수는 권한/녹음 성공을 보장하지 않음", "fallback": "--input audio.wav"}


def record_microphone(seconds: float = 5.0, *, consent: bool = False) -> np.ndarray:
    """consent=True를 명시한 사용자 조작에서만 마이크를 연다. 원음 자동 저장 없음."""
    if not consent:
        raise PermissionError("마이크 입력에는 명시적 녹음 동의가 필요합니다.")
    if not math.isfinite(seconds) or not .1 <= seconds <= MAX_SECONDS:
        raise ValueError("녹음 시간은 0.1~120초여야 합니다.")
    if not microphone_diagnostics()["available"]:
        raise RuntimeError("마이크 장치가 없습니다. --input audio.wav를 사용하세요.")

    class WaveFormat(ctypes.Structure):
        _pack_ = 1
        _fields_ = [("tag", ctypes.c_ushort), ("channels", ctypes.c_ushort),
                    ("rate", ctypes.c_uint32), ("bytes_per_second", ctypes.c_uint32),
                    ("align", ctypes.c_ushort), ("bits", ctypes.c_ushort), ("extra", ctypes.c_ushort)]

    class WaveHeader(ctypes.Structure):
        _fields_ = [("data", ctypes.c_void_p), ("length", ctypes.c_uint32),
                    ("recorded", ctypes.c_uint32), ("user", ctypes.c_size_t),
                    ("flags", ctypes.c_uint32), ("loops", ctypes.c_uint32),
                    ("next", ctypes.c_void_p), ("reserved", ctypes.c_size_t)]

    api = ctypes.WinDLL("winmm")
    api.waveInOpen.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_uint,
                              ctypes.POINTER(WaveFormat), ctypes.c_size_t, ctypes.c_size_t, ctypes.c_uint]
    for name in ("waveInPrepareHeader", "waveInAddBuffer", "waveInUnprepareHeader"):
        getattr(api, name).argtypes = [ctypes.c_void_p, ctypes.POINTER(WaveHeader), ctypes.c_uint]
    for name in ("waveInStart", "waveInReset", "waveInClose"):
        getattr(api, name).argtypes = [ctypes.c_void_p]

    def check(code: int) -> None:
        if code:
            raise RuntimeError(f"마이크 WinMM 오류 {code}: 장치/권한/16kHz 지원을 확인하거나 WAV 입력을 사용하세요.")

    handle = ctypes.c_void_p()
    fmt = WaveFormat(1, 1, SAMPLE_RATE, SAMPLE_RATE * 2, 2, 16, 0)
    check(api.waveInOpen(ctypes.byref(handle), 0xFFFFFFFF, ctypes.byref(fmt), 0, 0, 0))
    data = ctypes.create_string_buffer(int(seconds * SAMPLE_RATE) * 2)
    header = WaveHeader(ctypes.addressof(data), len(data), 0, 0, 0, 0, None, 0)
    prepared = False
    try:
        check(api.waveInPrepareHeader(handle, ctypes.byref(header), ctypes.sizeof(header)))
        prepared = True
        check(api.waveInAddBuffer(handle, ctypes.byref(header), ctypes.sizeof(header)))
        check(api.waveInStart(handle))
        deadline = time.monotonic() + seconds + 3
        while not header.flags & 1:
            if time.monotonic() >= deadline:
                raise TimeoutError("마이크 입력 시간 초과. WAV 입력을 사용하세요.")
            time.sleep(.02)
        if header.recorded < 2:
            raise RuntimeError("마이크에서 PCM을 받지 못했습니다.")
        return np.frombuffer(data.raw[:header.recorded - header.recorded % 2], dtype="<i2").astype(np.float32) / 32768
    finally:
        api.waveInReset(handle)
        if prepared:
            api.waveInUnprepareHeader(handle, ctypes.byref(header), ctypes.sizeof(header))
        api.waveInClose(handle)


def microphone_chunks(seconds: float = 10, *, consent: bool = False,
                      chunk_ms: int = 160, cancel=None):
    """명시 동의로 WinMM 버퍼를 순차 반환. 취소/예외/close 시 장치를 닫는다.

8개 순환 버퍼를 사용한다. 소비가 버퍼 시간보다 지연되면 누락 위험을 숨기지
않고 오류를 반환한다. 기본 자동 저장·자동 녹음·원격 전송은 없다.
"""
    if not consent:
        raise PermissionError('마이크 streaming에는 명시적 동의가 필요합니다.')
    if not math.isfinite(seconds) or not .1 <= seconds <= MAX_SECONDS or not 20 <= chunk_ms <= 2000:
        raise ValueError('녹음 시간 0.1~120초, chunk_ms 20~2000이 필요합니다.')
    if cancel is not None and cancel.is_set():
        return
    if not microphone_diagnostics()['available']:
        raise RuntimeError('마이크 장치가 없습니다. WAV 파일 입력을 사용하세요.')

    class Format(ctypes.Structure):
        _pack_ = 1
        _fields_ = [('tag',ctypes.c_ushort),('channels',ctypes.c_ushort),('rate',ctypes.c_uint32),
                    ('bps',ctypes.c_uint32),('align',ctypes.c_ushort),('bits',ctypes.c_ushort),('extra',ctypes.c_ushort)]
    class Header(ctypes.Structure):
        _fields_ = [('data',ctypes.c_void_p),('length',ctypes.c_uint32),('recorded',ctypes.c_uint32),
                    ('user',ctypes.c_size_t),('flags',ctypes.c_uint32),('loops',ctypes.c_uint32),
                    ('next',ctypes.c_void_p),('reserved',ctypes.c_size_t)]
    api=ctypes.WinDLL('winmm')
    api.waveInOpen.argtypes=[ctypes.POINTER(ctypes.c_void_p),ctypes.c_uint,ctypes.POINTER(Format),ctypes.c_size_t,ctypes.c_size_t,ctypes.c_uint]
    for name in ('waveInPrepareHeader','waveInAddBuffer','waveInUnprepareHeader'):
        getattr(api,name).argtypes=[ctypes.c_void_p,ctypes.POINTER(Header),ctypes.c_uint]
    for name in ('waveInStart','waveInReset','waveInClose'):
        getattr(api,name).argtypes=[ctypes.c_void_p]
    def check(code):
        if code:raise RuntimeError(f'WinMM streaming 오류 {code}; 장치/권한을 확인하거나 WAV 입력을 사용하세요.')
    handle=ctypes.c_void_p();fmt=Format(1,1,16000,32000,2,16,0)
    check(api.waveInOpen(ctypes.byref(handle),0xFFFFFFFF,ctypes.byref(fmt),0,0,0))
    buffers=[];prepared=[];target=int(seconds*16000);received=0
    try:
        for _ in range(8):
            buffer=ctypes.create_string_buffer(chunk_ms*32)
            header=Header(ctypes.addressof(buffer),len(buffer),0,0,0,0,None,0)
            buffers.append((buffer,header))
            check(api.waveInPrepareHeader(handle,ctypes.byref(header),ctypes.sizeof(header)))
            prepared.append(header)
            check(api.waveInAddBuffer(handle,ctypes.byref(header),ctypes.sizeof(header)))
        check(api.waveInStart(handle))
        index=0
        while received<target:
            if cancel is not None and cancel.is_set():break
            buffer,header=buffers[index]
            deadline=time.monotonic()+chunk_ms/1000+3
            while not header.flags&1:
                if cancel is not None and cancel.is_set():return
                if time.monotonic()>deadline:raise TimeoutError('마이크 PCM streaming 시간 초과')
                time.sleep(.005)
            if all(h.flags&1 for _,h in buffers):
                raise RuntimeError('마이크 소비 지연으로 모든 버퍼가 소진됨; chunk 크기를 늘리거나 빠른 모델을 선택하세요.')
            n=min(header.recorded//2,target-received)
            if not n:raise RuntimeError('마이크가 빈 버퍼를 반환했습니다.')
            pcm=np.frombuffer(buffer.raw[:n*2],dtype='<i2').astype(np.float32)/32768
            received+=n
            header.recorded=0
            check(api.waveInAddBuffer(handle,ctypes.byref(header),ctypes.sizeof(header)))
            index=(index+1)%len(buffers)
            yield pcm
    finally:
        api.waveInReset(handle)
        for header in prepared:api.waveInUnprepareHeader(handle,ctypes.byref(header),ctypes.sizeof(header))
        api.waveInClose(handle)
