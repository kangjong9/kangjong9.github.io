"""프랑스어 Zipformer online transducer의 파일 청크 스트리밍. 마이크 자동 입력 없음."""
import csv
import hashlib
import time
from pathlib import Path
import numpy as np
import sherpa_onnx

from .registry import ROOT
REVISION = '3db9565d9633758d6b87b9a7b3dc09ebfb6b2c73'


class FrenchStreaming:
    """실제 online state를 유지. timestamp는 모델 토큰 시작 초이며 단어 정렬 아님."""
    def __init__(self, decoding_method='greedy_search', max_active_paths=4):
        if decoding_method not in {'greedy_search','modified_beam_search'} or not 1 <= max_active_paths <= 32:
            raise ValueError('유효한 decoder와 max_active_paths 1~32가 필요합니다.')
        self.decoding_method=decoding_method
        self.max_active_paths=max_active_paths
        started=time.perf_counter()
        with (ROOT/'third_party/zipformer_fr_manifest.csv').open(encoding='utf-8',newline='') as f:
            for item in csv.DictReader(f):
                if hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()!=item['sha256']:
                    raise RuntimeError('Zipformer 자산 무결성 실패')
        folder=ROOT/'models/zipformer-fr'
        paths={part:str(folder/f'{part}-epoch-29-avg-9-with-averaged-model.int8.onnx') for part in ['encoder','decoder','joiner']}
        self.recognizer=sherpa_onnx.OnlineRecognizer.from_transducer(
            tokens=str(folder/'tokens.txt'),**paths,num_threads=2,sample_rate=16000,
            decoding_method=decoding_method,max_active_paths=max_active_paths,enable_endpoint_detection=False,provider='cpu')
        self.load_ms=(time.perf_counter()-started)*1000

    def stream(self, audio: np.ndarray, language: str='fr', chunk_ms: int=160):
        """기존 파일 입력 호환. online state를 청크 사이 유지한다."""
        audio=np.asarray(audio,dtype=np.float32)
        if audio.ndim!=1 or not len(audio) or not np.isfinite(audio).all() or not 20<=chunk_ms<=2000:
            raise ValueError('유효한 mono PCM 및 20~2000ms 청크가 필요합니다.')
        count=chunk_ms*16
        yield from self.stream_chunks((audio[i:i+count] for i in range(0,len(audio),count)),
                                      language=language, feed_mode='file fast-feed')

    def stream_microphone(self, seconds=10, *, consent=False, chunk_ms=160, cancel=None, language='fr'):
        """명시 사용자 조작 후 호출. 생성자에서 모델을 먼저 로드한다."""
        from .capture import microphone_chunks
        chunks=microphone_chunks(seconds,consent=consent,chunk_ms=chunk_ms,cancel=cancel)
        yield from self.stream_chunks(chunks,language=language,cancel=cancel,feed_mode='live microphone')

    def stream_chunks(self, chunks, *, language='fr', cancel=None, feed_mode='provided chunks'):
        """청크 iterable 공통 처리. 취소를 성공 전사로 반환하지 않는다."""
        if language.split('-')[0]!='fr':
            raise ValueError('이 streaming 모델은 프랑스어만 지원합니다.')
        stream=self.recognizer.create_stream()
        start=time.perf_counter(); previous=''; first=None; received=0
        iterator=iter(chunks)
        def result_dict(status, result, reason=None):
            return dict(status=status,task='streaming',transcript=result.text.strip() if result else None,
                tokens=list(result.tokens) if result else [],timestamps=list(result.timestamps) if result else [],
                phone_hypotheses=[],target_phone=None,phone_match=None,reject_reason=reason,
                locale=None,l1=None,score_type='unscored',language='fr',validated=False,
                model_id='zipformer-fr-int8',model_revision=REVISION,
                runtime_ms=(time.perf_counter()-start)*1000,first_partial_ms=first,
                audio_received_seconds=received/16000,model_load_ms=self.load_ms,
                timestamp_type='model token start seconds',feed_mode=feed_mode)
        try:
            while True:
                if cancel is not None and cancel.is_set():
                    yield result_dict('cancelled',None,'user_cancelled');return
                try:pcm=next(iterator)
                except StopIteration:break
                pcm=np.asarray(pcm,dtype=np.float32)
                if pcm.ndim!=1 or not len(pcm) or len(pcm)>32000 or not np.isfinite(pcm).all():
                    raise ValueError('청크는 유한한 mono PCM 1~32000 samples이어야 합니다.')
                received+=len(pcm)
                if received>16000*120:raise ValueError('streaming 최대 120초 초과')
                stream.accept_waveform(16000,pcm)
                while self.recognizer.is_ready(stream):
                    self.recognizer.decode_stream(stream)
                    if cancel is not None and cancel.is_set():
                        yield result_dict('cancelled',None,'user_cancelled');return
                result=self.recognizer.get_result_all(stream)
                text=result.text.strip()
                if text and text!=previous:
                    if first is None:first=(time.perf_counter()-start)*1000
                    yield result_dict('partial',result)
                    previous=text
            if cancel is not None and cancel.is_set():
                yield result_dict('cancelled',None,'user_cancelled');return
            if not received:
                yield result_dict('unknown',None,'insufficient_audio');return
            stream.accept_waveform(16000,np.zeros(8000,np.float32))
            stream.input_finished()
            while self.recognizer.is_ready(stream):
                self.recognizer.decode_stream(stream)
                if cancel is not None and cancel.is_set():
                    yield result_dict('cancelled',None,'user_cancelled');return
            result=self.recognizer.get_result_all(stream)
            output=result_dict('recognized' if result.text.strip() else 'unknown',result,
                               None if result.text.strip() else 'no_transcript')
            output['flush_padding_seconds']=.5
            yield output
        finally:
            close=getattr(iterator,'close',None)
            if close:close()
