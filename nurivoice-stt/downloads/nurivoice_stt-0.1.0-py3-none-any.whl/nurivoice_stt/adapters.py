import json
import time
import threading
import numpy as np
from .registry import MODELS

_lock = threading.RLock()
_cache = {}
_metrics = threading.local()

def metrics():
    """현재 스레드의 직전 모델 호출 시간. 전체 API 시간과 별도."""
    return getattr(_metrics, 'value', {}).copy()

def phone_evidence(target, competitors):
    """CTC 프레임 원점수 비교. 확률·정밀 발음 점수가 아니다."""
    evidence=getattr(_metrics,'phone_scores',{})
    return {'score_type':'mean_frame_logits_unscaled','target':evidence.get(target),
            'competitors':{p:evidence[p] for p in competitors if p in evidence},
            'calibrated':False}

def clear_cache():
    """동시 추론 완료 뒤 모델 메모리 참조 해제."""
    with _lock:
        _cache.clear()

def _get(key, factory):
    signature=tuple((p.name,p.stat().st_size,p.stat().st_mtime_ns) for p in sorted(MODELS.iterdir()) if p.suffix in {'.onnx','.csv','.txt','.json'})
    key=(key,signature)
    start = time.perf_counter()
    hit = key in _cache
    if not hit:
        # 모델은 한 종류만 유지해 작은 PC에서 무제한 메모리 증가 방지.
        _cache.clear()
        _cache[key] = factory()
    _metrics.value = {'cache_hit': hit, 'model_load_ms': (time.perf_counter()-start)*1000}
    return _cache[key]

def transcribe(x,language,model):
    import sherpa_onnx
    with _lock:
        r=_get(('whisper',model,language),lambda:sherpa_onnx.OfflineRecognizer.from_whisper(encoder=str(MODELS/f'whisper-{model}-encoder.onnx'),decoder=str(MODELS/f'whisper-{model}-decoder.onnx'),tokens=str(MODELS/'whisper-tokens.txt'),language=language,num_threads=2))
        start=time.perf_counter()
        s=r.create_stream(); s.accept_waveform(16000,x); r.decode_stream(s)
        _metrics.value['inference_ms']=(time.perf_counter()-start)*1000
        return s.result.text

def identify_language(x, model='tiny'):
    """실제 Whisper 언어 토큰 판별. 확률이나 지역형을 추측하지 않는다."""
    import sherpa_onnx as s
    with _lock:
        def factory():
            whisper=s.SpokenLanguageIdentificationWhisperConfig(
                encoder=str(MODELS/f'whisper-{model}-encoder.onnx'),
                decoder=str(MODELS/f'whisper-{model}-decoder.onnx'))
            return s.SpokenLanguageIdentification(s.SpokenLanguageIdentificationConfig(
                whisper=whisper,num_threads=2,provider='cpu'))
        detector=_get(('language_id',model),factory)
        start=time.perf_counter()
        stream=detector.create_stream()
        stream.accept_waveform(16000,x)
        language=detector.compute(stream)
        _metrics.value['inference_ms']=(time.perf_counter()-start)*1000
        return language

def phones(x):
    import onnxruntime as ort
    options=ort.SessionOptions(); options.intra_op_num_threads=2; options.inter_op_num_threads=1
    vocab=json.loads((MODELS/'vocab.json').read_text(encoding='utf-8')); vocab={v:k for k,v in vocab.items()}
    x=((x-x.mean())/np.sqrt(x.var()+1e-7)).astype(np.float32)
    with _lock:
        s=_get(('phoneme',),lambda:ort.InferenceSession(str(MODELS/'phoneme.onnx'),sess_options=options,providers=['CPUExecutionProvider']))
        start=time.perf_counter()
        feed={i.name:np.ones((1,len(x)),dtype=np.int64) if 'mask' in i.name else x[None,:] for i in s.get_inputs()}
        logits=s.run(None,feed)[0]
        ids=logits.argmax(-1).reshape(-1).tolist()
        means=logits.reshape(-1,logits.shape[-1]).mean(axis=0)
        _metrics.phone_scores={vocab[i]:float(v) for i,v in enumerate(means) if i in vocab}
        _metrics.value['inference_ms']=(time.perf_counter()-start)*1000
    return [vocab[v] for j,v in enumerate(ids) if v!=0 and (j==0 or ids[j-1]!=v)]
