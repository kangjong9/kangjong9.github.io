from pathlib import Path
import os
ROOT = Path(os.environ.get('NURIVOICE_HOME',Path(__file__).resolve().parents[2])).resolve()
MODELS = ROOT / 'models'
LANGUAGES = {'en','ja','zh','fr','es','ru','pt','it','de','no','ko'}
LOCALES = ['en-US','en-GB','en-AU','en-CA','ja-JP','zh-CN','zh-TW','zh-HK','fr-FR','fr-CA','fr-BE','es-ES','es-MX','es-AR','ru-RU','pt-PT','pt-BR','it-IT','de-DE','de-AT','de-CH','nb-NO','ko-KR']

def verify_models(model):
    import csv,hashlib
    needed={'phoneme.onnx','vocab.json'} if model=='phoneme' else {f'whisper-{model}-encoder.onnx',f'whisper-{model}-decoder.onnx','whisper-tokens.txt'}
    with (MODELS/'manifest.csv').open(encoding='utf-8') as f:
        rows={r['artifact']:r for r in csv.DictReader(f)}
    for name in needed:
        if name not in rows: raise ValueError('Missing manifest entry: '+name)
        h=hashlib.sha256()
        with (MODELS/name).open('rb') as f:
            for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
        if h.hexdigest()!=rows[name]['sha256']: raise ValueError('Model integrity mismatch: '+name)
