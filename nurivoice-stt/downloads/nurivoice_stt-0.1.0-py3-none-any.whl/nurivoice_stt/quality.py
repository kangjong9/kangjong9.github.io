import numpy as np
def inspect_audio(x):
    if len(x) < 1600: return 'insufficient_audio'
    if not np.isfinite(x).all(): return 'invalid_audio'
    rms = float(np.sqrt(np.mean(x*x)))
    if rms < 1e-5: return 'silence'
    if np.mean(np.abs(x)>=.99) > .02: return 'clipping'
    # Conservative experimental quality rule, not a learned speech detector.
    zcr = float(np.mean(np.signbit(x[1:]) != np.signbit(x[:-1])))
    if zcr > .35: return 'noise'
    return None
