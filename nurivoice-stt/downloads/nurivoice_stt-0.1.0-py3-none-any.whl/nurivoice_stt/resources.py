"""프로세스 자원 관측. 모델 전용 메모리나 GPU 메모리가 아니다."""
import ctypes
import sys

def process_memory():
    if sys.platform != 'win32': return {'available':False}
    class Counters(ctypes.Structure):
        _fields_=[('cb',ctypes.c_ulong),('PageFaultCount',ctypes.c_ulong)]+[(n,ctypes.c_size_t) for n in ['PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage']]
    kernel=ctypes.WinDLL('kernel32'); kernel.GetCurrentProcess.restype=ctypes.c_void_p
    psapi=ctypes.WinDLL('psapi'); psapi.GetProcessMemoryInfo.argtypes=[ctypes.c_void_p,ctypes.POINTER(Counters),ctypes.c_ulong]
    c=Counters();c.cb=ctypes.sizeof(c)
    if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(),ctypes.byref(c),c.cb):
        return {'available':False}
    return {'available':True,'working_set_bytes':c.WorkingSetSize,'process_lifetime_peak_bytes':c.PeakWorkingSetSize,'scope':'process, includes Python and libraries; not per-model peak','VRAM':'NOT_MEASURED'}
