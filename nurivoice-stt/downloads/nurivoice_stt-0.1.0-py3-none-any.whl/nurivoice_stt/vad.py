"""Silero ONNX 음성 구간 검출. 확률은 발음 점수/음소 식별 결과가 아니다.

ONNX state/context 계약: third_party/silero_vad/utils_vad.py (MIT).
구간화는 별도 구현이며 기본 임계값은 이 프로젝트 음소에 보정되지 않았다.
"""
from pathlib import Path
from functools import lru_cache
import hashlib
import numpy as np
import onnxruntime as ort

from .registry import ROOT
MODEL = ROOT / 'models' / 'silero_vad.onnx'
MODEL_SHA = '1a153a22f4509e292a94e67d6f9b85e8deb25b4988682b7e174c65279d8788e3'


@lru_cache(maxsize=1)
def _session():
    if hashlib.sha256(MODEL.read_bytes()).hexdigest() != MODEL_SHA:
        raise RuntimeError('Silero 모델 해시가 일치하지 않습니다.')
    options = ort.SessionOptions()
    options.intra_op_num_threads = options.inter_op_num_threads = 1
    return ort.InferenceSession(str(MODEL), options, providers=['CPUExecutionProvider'])


def speech_segments(x: np.ndarray, sr: int = 16000, *, threshold: float = .5,
                    padding_ms: int = 160, min_silence_ms: int = 100) -> list[dict]:
    """반환 start/end는 샘플 인덱스(end exclusive). 상태는 매 호출마다 초기화.

짧은 모음 삭제를 피하려고 최소 발화 길이 필터는 적용하지 않는다.
padding은 검출 경계 여유이며 실제 음소 잘림 방지 보장이 아니다.
"""
    x = np.asarray(x, dtype=np.float32)
    if sr != 16000 or x.ndim != 1 or not np.isfinite(x).all():
        raise ValueError('VAD 입력은 유한한 16kHz mono PCM이어야 합니다.')
    if not 0 < threshold < 1 or padding_ms < 0 or min_silence_ms < 0:
        raise ValueError('VAD 매개변수가 유효하지 않습니다.')
    if not len(x):
        return []
    if hashlib.sha256(MODEL.read_bytes()).hexdigest() != MODEL_SHA:
        raise RuntimeError('Silero 모델 해시가 일치하지 않습니다.')
    session = _session()
    state = np.zeros((2, 1, 128), np.float32)
    context = np.zeros((1, 64), np.float32)
    probabilities = []
    for i in range(0, len(x), 512):
        chunk = np.zeros((1, 512), np.float32)
        part = x[i:i+512]
        chunk[0, :len(part)] = part
        pcm = np.concatenate([context, chunk], axis=1)
        out, state = session.run(None, {'input': pcm, 'state': state, 'sr': np.array(sr, dtype=np.int64)})
        probabilities.append(float(out.reshape(-1)[0]))
        context = chunk[:, -64:]
    # Hysteresis avoids rapidly toggling near the opening threshold.
    spans = []
    start = None
    silence = None
    for frame, p in enumerate(probabilities):
        at = frame * 512
        if start is None and p >= threshold:
            start = at
        if start is not None:
            if p >= threshold - .15:
                silence = None
            elif silence is None:
                silence = at
            elif at - silence >= sr * min_silence_ms / 1000:
                spans.append((start, silence))
                start = silence = None
    if start is not None:
        spans.append((start, len(x)))
    pad = int(sr * padding_ms / 1000)
    result = []
    for start, end in spans:
        start, end = max(0, start-pad), min(len(x), end+pad)
        if result and start <= result[-1]['end']:
            result[-1]['end'] = max(end, result[-1]['end'])
        else:
            result.append({'start': start, 'end': end})
    return result
