"""다른 앱을 변경하지 않고 독립 SDK로 호출하는 예제."""
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from nurivoice_stt import recognize
if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('usage: sdk_example.py input.wav')
    print(json.dumps(recognize(sys.argv[1],language='en'),ensure_ascii=True))
