﻿$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$python = Join-Path $projectRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python)) { throw '먼저 scripts/setup_environment.ps1을 실행하세요.' }
$workspaceRoot = Split-Path -Parent (Split-Path -Parent $projectRoot)
$expectedHome = 'home = ' + (Join-Path $workspaceRoot '03. Program\Python')
if (-not ((Get-Content -Encoding UTF8 -LiteralPath (Join-Path $projectRoot '.venv\pyvenv.cfg')) -contains $expectedHome)) {
    throw 'Drive relocation detected. Run scripts/setup_environment.ps1 to repair the environment.'
}
$env:NURIVOICE_HOME = $projectRoot
$env:PYTHONNOUSERSITE = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
& $python -B -m nurivoice_stt @args
exit $LASTEXITCODE
