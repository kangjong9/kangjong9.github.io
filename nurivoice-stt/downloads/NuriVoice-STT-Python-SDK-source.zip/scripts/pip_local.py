"""Run pip with a project-local temporary directory even under portable sitecustomize."""
import os
from pathlib import Path
import runpy
import tempfile

root=Path(__file__).resolve().parents[1]
temporary=root/'.build-temp'
temporary.mkdir(exist_ok=True)
os.environ['TEMP']=os.environ['TMP']=str(temporary)
os.environ['PIP_CACHE_DIR']=str(root/'.download-cache')
os.environ['PIP_CONFIG_FILE']='NUL'
os.environ['PIP_DISABLE_PIP_VERSION_CHECK']='1'
tempfile.tempdir=str(temporary)
runpy.run_module('pip',run_name='__main__')
