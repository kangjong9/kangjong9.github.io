"""NuriVoice 로컬 초안 UI. 추론은 숨겨진 자식 프로세스, UI 갱신은 main thread."""
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
os.environ['NURIVOICE_HOME'] = str(ROOT)
sys.path.insert(0, str(ROOT / 'src'))


def worker():
    """마이크는 UI의 명시 확인 후 전달된 요청만 실행한다."""
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stdin.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    request = json.loads(sys.stdin.readline())
    from nurivoice_stt.api import recognize
    if request['task'] == 'streaming':
        from nurivoice_stt.streaming import FrenchStreaming
        from nurivoice_stt.capture import read_wav
        from nurivoice_stt.quality import inspect_audio
        engine = FrenchStreaming()
        if request['mic']:
            events = engine.stream_microphone(consent=True, seconds=10)
        else:
            audio = read_wav(request['path'])
            rejection = inspect_audio(audio)
            if rejection:
                print(json.dumps({'status':'rejected','reject_reason':rejection}), flush=True)
                return
            events = engine.stream(audio)
        for result in events:
            print(json.dumps(result, ensure_ascii=False), flush=True)
    else:
        print(json.dumps(recognize(**request), ensure_ascii=False), flush=True)


def main():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    import winsound

    window = tk.Tk()
    window.title('NuriVoice STT — 실행 초안')
    window.geometry('1060x850')
    window.minsize(900, 800)
    window.configure(bg='#EEF3F8')
    icon = ROOT / 'assets' / 'nurivoice.ico'
    if icon.exists(): window.iconbitmap(str(icon))
    style = ttk.Style(window)
    style.theme_use('clam')
    style.configure('.', font=('맑은 고딕', 11))
    style.configure('TFrame', background='#EEF3F8')
    style.configure('TLabel', background='#EEF3F8', foreground='#203448')
    style.configure('TButton', padding=(14, 9), background='#FFFFFF')
    style.configure('Accent.TButton', background='#2357B2', foreground='white', font=('맑은 고딕', 12, 'bold'))
    style.map('Accent.TButton', background=[('active','#18418B'),('disabled','#ABBBD2')])
    style.configure('TCombobox', padding=6)
    shell = ttk.Frame(window, padding=28)
    shell.pack(fill='both', expand=True)
    header = ttk.Frame(shell); header.pack(fill='x')
    ttk.Label(header, text='NuriVoice', font=('Segoe UI', 30, 'bold'), foreground='#2357B2').pack(side='left')
    ttk.Label(header, text='STT  /  실행 초안', font=('맑은 고딕', 13)).pack(side='left', padx=18, pady=(15,0))
    ttk.Label(shell, text='음성을 넣고, 인식된 문장을 직접 확인하세요.', font=('맑은 고딕',14)).pack(anchor='w', pady=(4,20))

    filepath = tk.StringVar()
    language = tk.StringVar(value='자동 식별')
    model = tk.StringVar(value='자동 선택')
    mode = tk.StringVar(value='문장 전사')
    target = tk.StringVar(value='a')
    status = tk.StringVar(value='준비됨  ·  예제 실행 또는 WAV 파일 선택')
    details = tk.StringVar(value='파일은 로컬에서 처리됩니다. 마이크는 녹음 버튼을 눌러 확인한 뒤에만 켜집니다.')
    lang_map = {'자동 식별':'auto','한국어':'ko','영어':'en','프랑스어':'fr','일본어':'ja','중국어':'zh',
                '스페인어':'es','러시아어':'ru','포르투갈어':'pt','이탈리아어':'it','독일어':'de','노르웨이어':'no'}
    mode_map = {'문장 전사':'transcribe','프랑스어 스트리밍':'streaming','프랑스어 음소 연구':'phoneme'}
    model_map = {'자동 선택':'auto','경량 tiny':'tiny','정확도 비교 base':'base'}
    messages = queue.Queue()
    state = {'process':None,'busy':False,'result':None,'job':0,'closed':False}

    examples = ttk.Frame(shell); examples.pack(fill='x', pady=(0,14))
    ttk.Label(examples, text='바로 체험', font=('맑은 고딕',11,'bold')).pack(side='left', padx=(0,14))
    sample_files = {'영어':ROOT/'datasets/librispeech_1272_128104_0000.wav'}
    manifest = ROOT/'datasets/public_multilingual/manifest.json'
    if manifest.exists():
        for item in json.loads(manifest.read_text(encoding='utf-8'))['samples']:
            label = {'fr':'프랑스어','ko':'한국어'}.get(item['language'])
            if label and label not in sample_files: sample_files[label] = manifest.parent/item['path']

    source = ttk.Frame(shell); source.pack(fill='x')
    file_entry = ttk.Entry(source, textvariable=filepath)
    file_entry.pack(side='left', fill='x', expand=True, ipady=7)
    def choose_file():
        chosen = filedialog.askopenfilename(title='인식할 음성 파일', filetypes=[('WAV 음성','*.wav')], parent=window)
        if chosen: filepath.set(chosen)
    choose = ttk.Button(source, text='WAV 선택', command=choose_file)
    choose.pack(side='left', padx=(10,0))
    options = ttk.Frame(shell); options.pack(fill='x', pady=(16,12))
    controls = [choose, file_entry]
    for label, variable, values, width in [('작업',mode,list(mode_map),21),('언어',language,list(lang_map),15),('모델',model,list(model_map),20)]:
        group = ttk.Frame(options); group.pack(side='left', padx=(0,18))
        ttk.Label(group,text=label).pack(anchor='w',pady=(0,4))
        box = ttk.Combobox(group,textvariable=variable,values=values,state='readonly',width=width)
        box.pack(); controls.append(box)
    target_group = ttk.Frame(options); target_group.pack(side='left')
    ttk.Label(target_group,text='목표 음소').pack(anchor='w',pady=(0,4))
    target_entry = ttk.Entry(target_group,textvariable=target,width=6); target_entry.pack(ipady=7)
    controls.append(target_entry)
    def mode_changed(*_):
        if mode.get()!='문장 전사': language.set('프랑스어')
    mode.trace_add('write',mode_changed)

    actions = ttk.Frame(shell); actions.pack(fill='x',pady=(0,12))
    result_header = ttk.Frame(shell)
    progress = ttk.Progressbar(shell,mode='indeterminate')
    progress.pack(fill='x',pady=(0,12))
    ttk.Label(shell,textvariable=status,font=('맑은 고딕',12,'bold')).pack(anchor='w',pady=(0,8))
    result_header.pack(fill='x')
    ttk.Label(result_header,text='인식 결과',font=('맑은 고딕',14,'bold')).pack(side='left')
    output = tk.Text(shell,wrap='word',font=('맑은 고딕',18),bg='#FFFFFF',fg='#203448',relief='flat',
                     padx=22,pady=20,height=5,insertbackground='#2357B2')
    output.pack(fill='both',expand=True,pady=(10,12))
    output.insert('1.0','위의 예제 버튼을 누르면 실제 공개 음성을 인식합니다.\n직접 준비한 WAV 파일도 선택할 수 있습니다.')
    output.configure(state='disabled')
    ttk.Label(shell,textvariable=details,wraplength=950).pack(anchor='w',pady=(0,8))
    ttk.Label(shell,text='음소 연구 결과는 발음 합격 점수가 아닙니다. 스트리밍은 현재 프랑스어 경로를 사용합니다.',
              foreground='#576D80',font=('맑은 고딕',10)).pack(anchor='w')

    def replace_output(text):
        output.configure(state='normal'); output.delete('1.0','end'); output.insert('1.0',text); output.configure(state='disabled')

    def busy(value):
        state['busy']=value
        for control in controls:
            control.configure(state='disabled' if value else ('readonly' if isinstance(control,ttk.Combobox) else 'normal'))
        stop.configure(state='normal' if value else 'disabled')
        if value: progress.start(12)
        else: progress.stop()

    def background(request,job):
        process=None
        try:
            runtime = ROOT/'.venv/Scripts/python.exe'
            if not runtime.exists(): raise RuntimeError('프로젝트 .venv가 없습니다. scripts/setup_environment.ps1을 실행하세요.')
            process=subprocess.Popen([str(runtime),'-B',str(Path(__file__).resolve()),'--worker'],
                stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',
                cwd=ROOT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            if job!=state['job'] or state['closed']:
                process.terminate();process.wait();return
            state['process']=process
            errors=[]
            error_reader=threading.Thread(target=lambda:errors.append(process.stderr.read()),daemon=True)
            error_reader.start()
            process.stdin.write(json.dumps(request,ensure_ascii=False)+'\n');process.stdin.close()
            for line in process.stdout:
                try: messages.put((job,'result',json.loads(line)))
                except json.JSONDecodeError: errors.append(line)
            code=process.wait();error_reader.join(timeout=2)
            if code: raise RuntimeError(''.join(errors).strip() or f'인식 프로세스 종료 코드 {code}')
        except Exception as exc:
            messages.put((job,'error',str(exc)))
        finally:
            if process is not None and process.poll() is None: process.terminate();process.wait()
            messages.put((job,'done',None))

    def start(mic=False):
        if state['busy']: return
        if mic and not messagebox.askokcancel('마이크 녹음 시작',
                '지금 마이크를 켜서 녹음합니다.\n일반 전사 5초 / 스트리밍 10초\n음성은 외부로 전송하지 않습니다.\n시작할까요?',parent=window): return
        if not mic and not Path(filepath.get()).is_file():
            status.set('WAV 파일을 선택하거나 예제 버튼을 눌러주세요.');return
        task=mode_map[mode.get()]
        request=dict(path=None if mic else filepath.get(),task=task,language=lang_map[language.get()],
                     model=model_map[model.get()],mic=mic,l1='ko' if task=='phoneme' else None,
                     target=target.get().strip() if task=='phoneme' else None)
        if task!='transcribe' and request['language']!='fr':
            status.set('이 작업은 언어를 프랑스어로 선택하세요.');return
        state['job']+=1;state['result']=None
        busy(True);status.set('녹음·인식 중…' if mic else '음성 인식 중…')
        details.set('모델을 준비하고 음성을 처리하고 있습니다. 중지 버튼으로 취소할 수 있습니다.')
        replace_output('')
        threading.Thread(target=background,args=(request,state['job']),daemon=True).start()

    def sample(label):
        if state['busy']: return
        filepath.set(str(sample_files[label]));language.set(label);mode.set('문장 전사');start()

    for label in sample_files:
        button=ttk.Button(examples,text=label+' 예제 실행',command=lambda label=label:sample(label))
        button.pack(side='left',padx=(0,8));controls.append(button)

    run=ttk.Button(actions,text='파일 인식 시작',style='Accent.TButton',command=start)
    run.pack(side='left');controls.append(run)
    mic=ttk.Button(actions,text='마이크로 녹음',command=lambda:start(True));mic.pack(side='left',padx=10);controls.append(mic)
    def cancel():
        state['job']+=1
        process=state['process']
        if process is not None and process.poll() is None: process.terminate()
        state['process']=None;busy(False);status.set('중지됨');details.set('입력 파일은 변경되지 않았습니다.')
    stop=ttk.Button(actions,text='중지',command=cancel,state='disabled');stop.pack(side='left')
    def play():
        if Path(filepath.get()).is_file():
            try: winsound.PlaySound(filepath.get(),winsound.SND_FILENAME|winsound.SND_ASYNC)
            except RuntimeError as exc: status.set(str(exc))
    listen=ttk.Button(actions,text='입력 음성 듣기',command=play);listen.pack(side='right');controls.append(listen)
    def copy():
        window.clipboard_clear();window.clipboard_append(output.get('1.0','end-1c'));status.set('결과를 복사했습니다.')
    ttk.Button(result_header,text='복사',command=copy).pack(side='right')
    def save():
        if not state['result']: status.set('먼저 음성을 인식하세요.');return
        destination=filedialog.asksaveasfilename(parent=window,title='결과 저장',defaultextension='.json',filetypes=[('JSON 결과','*.json')])
        if destination:
            try: Path(destination).write_text(json.dumps(state['result'],ensure_ascii=False,indent=2),encoding='utf-8');status.set('결과를 저장했습니다.')
            except OSError as exc: messagebox.showerror('저장 오류',str(exc),parent=window)
    ttk.Button(result_header,text='JSON 저장',command=save).pack(side='right',padx=8)

    def poll():
        while not messages.empty():
            job,kind,value=messages.get()
            if job!=state['job']: continue
            if kind=='result':
                state['result']=value
                text=value.get('transcript')
                if not text and value.get('phone_hypotheses'): text='인식 후보: '+' / '.join(value['phone_hypotheses'])
                if not text: text='결과 없음: '+str(value.get('reject_reason') or value.get('status'))
                replace_output(text)
                names={'recognized':'인식 완료','partial':'부분 결과 수신 중…','rejected':'입력 거부','unknown':'판별 불확실','unsupported':'지원하지 않는 요청','error':'실행 오류'}
                status.set(names.get(value['status'],value['status']))
                details.set(f"언어 {value.get('language','—')}    모델 {value.get('model_id','—')}    처리 {value.get('runtime_ms',0)/1000:.2f}초")
                if value.get('error'): details.set(value['error'])
                if '--demo' in sys.argv and value['status']!='partial':
                    (ROOT/'reports/desktop_demo_result.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
            elif kind=='error':
                status.set('실행 오류');replace_output(value)
                (ROOT/'reports/desktop_error.log').write_text(value,encoding='utf-8')
                details.set('상세 기록: reports/desktop_error.log')
            else:
                state['process']=None;busy(False)
        if not state['closed']: window.after(80,poll)

    def close():
        if state['busy'] and not messagebox.askokcancel('종료','진행 중인 인식을 중지하고 종료할까요?',parent=window): return
        cancel();state['closed']=True;winsound.PlaySound(None,0);window.destroy()
    window.protocol('WM_DELETE_WINDOW',close)
    window.after(80,poll)
    if '--demo' in sys.argv: window.after(500,lambda:sample('영어'))
    if '--self-test' in sys.argv:
        # 실제 창의 콜백/worker/표시/중지 경로를 검증한다. 마이크 호출 없음.
        checks=[]
        deadline=time.monotonic()+45
        stage={'value':'start'}
        def ui_check():
            if time.monotonic()>deadline:
                checks.append({'check':'timeout','passed':False})
                finish_test();return
            current=stage['value']
            if current=='start':
                sample('영어');stage['value']='recognized'
            elif current=='recognized' and not state['busy']:
                checks.append({'check':'real_audio_visible','passed':state['result'] is not None and state['result']['status']=='recognized' and 'Quilter' in output.get('1.0','end')})
                filepath.set(str(ROOT/'README.md'));start();stage['value']='error'
            elif current=='error' and not state['busy']:
                checks.append({'check':'bad_audio_shows_error','passed':state['result'] is not None and state['result']['status']=='error' and status.get()=='실행 오류'})
                sample('영어');window.after(50,cancel);stage['value']='cancel'
            elif current=='cancel' and not state['busy']:
                checks.append({'check':'cancel_restores_controls','passed':status.get()=='중지됨' and str(run.cget('state'))=='normal'})
                finish_test();return
            window.after(100,ui_check)
        def finish_test():
            (ROOT/'reports/desktop_ui_test.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
            close()
        window.after(200,ui_check)
    window.mainloop()


if __name__=='__main__':
    try:
        if '--worker' in sys.argv: worker()
        else: main()
    except Exception:
        failure=traceback.format_exc()
        (ROOT/'reports').mkdir(exist_ok=True)
        (ROOT/'reports/desktop_error.log').write_text(failure,encoding='utf-8')
        if '--worker' in sys.argv:
            print(json.dumps({'status':'error','error':failure}),flush=True)
            raise SystemExit(1)
        import ctypes
        ctypes.windll.user32.MessageBoxW(None,failure,'NuriVoice 시작 오류',0x10)
