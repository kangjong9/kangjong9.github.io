﻿$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$workspaceRoot = Split-Path -Parent (Split-Path -Parent $projectRoot)
$basePython = Join-Path $workspaceRoot '03. Program\Python\python.exe'
$envRoot = Join-Path $projectRoot '.venv'
$tempRoot = Join-Path $projectRoot '.build-temp'
$cacheRoot = Join-Path $projectRoot '.download-cache'
New-Item -ItemType Directory -Force -Path $tempRoot, $cacheRoot | Out-Null
$env:TEMP = $tempRoot
$env:TMP = $tempRoot
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PIP_CACHE_DIR = $cacheRoot
$env:PIP_CONFIG_FILE = 'NUL'
$env:PYTHONNOUSERSITE = '1'
if (-not (Test-Path -LiteralPath (Join-Path $envRoot 'Scripts\python.exe'))) {
    & $basePython -B -m venv $envRoot
    if ($LASTEXITCODE -ne 0) { throw '프로젝트 가상환경 생성 실패' }
}
# A venv stores an absolute base-Python path. Repair it after drive relocation.
$cfgPath = Join-Path $envRoot 'pyvenv.cfg'
$baseHome = Split-Path -Parent $basePython
$expectedHome = 'home = ' + $baseHome
if (-not ((Get-Content -Encoding UTF8 -LiteralPath $cfgPath) -contains $expectedHome)) {
    & $basePython -B -m venv --upgrade $envRoot
    if ($LASTEXITCODE -ne 0) { throw 'Virtual environment repair after relocation failed' }
}
$python = Join-Path $envRoot 'Scripts\python.exe'
& $python -B (Join-Path $PSScriptRoot 'pip_local.py') install --index-url https://pypi.org/simple --only-binary=:all: --report (Join-Path $projectRoot 'third_party\environment_install_report.json') -r (Join-Path $projectRoot 'requirements-lock.txt') setuptools wheel
if ($LASTEXITCODE -ne 0) { throw '의존성 설치 실패; 공유 런타임은 변경하지 않았습니다.' }
& $python -B (Join-Path $PSScriptRoot 'pip_local.py') install --no-deps --no-build-isolation -e $projectRoot
if ($LASTEXITCODE -ne 0) { throw '프로젝트 editable 설치 실패' }
$env:NURIVOICE_HOME = $projectRoot
& $python -B (Join-Path $PSScriptRoot 'doctor.py')
if ($LASTEXITCODE -ne 0) { throw '설치 후 환경 진단 실패' }
