# NuriVoice STT Alpha

## 폰에서 바로 사용 — GitHub 운영

**https://kangjong9.github.io/nurivoice-stt/**

홈페이지 **작업물 폴더 → 네트워크 해봐? → TTS 옆 누리보이스 STT엔진**에서도 열 수 있습니다.
폰 브라우저에서 예제 버튼, 음성 파일 선택 또는 녹음 시작을 사용하세요. 최초 선택 모델은 GitHub에서 다운로드하며, 이후 음성 인식은 기기 브라우저 안에서 수행합니다. 음성을 서버에 업로드하지 않습니다.

웹 소스: `web/`. GitHub 운영본: `kangjong9/kangjong9.github.io` 저장소 `nurivoice-stt/`.
모델·WASM·JS·라이선스를 모두 같은 GitHub Pages에서 제공합니다. STT 실행에 PC 서버·외부 CDN·Hugging Face·유료 API가 필요하지 않습니다.
프랑스어 청크 모드는 녹음이 끝난 뒤 상태를 유지하며 처리하는 경로입니다. 실시간 모바일 녹음 중 부분전사로 표시하지 않습니다.

배포 및 실제 공개 추론 확인: `reports/GITHUB_MOBILE_DEPLOYMENT.md`. 공개 브라우저 시험은 데스크톱 Chromium의 모바일 화면 크기로 수행했으며, 사용자 폰 기종별 속도와 실제 마이크 녹음은 별도입니다.

업데이트할 때 `web/version.json`과 `web/sw.js`의 버전을 함께 올리고 검증한 뒤 배포합니다. 서비스워커는 새 버전을 알리고, 녹음/인식 중에는 강제로 교체하지 않습니다. 기존 홈페이지 전체를 과거 사본으로 덮지 말고 원격 최신본에 STT 경로/카드 변경만 적용합니다.

## 직접 실행하는 초안

**프로젝트 폴더의 `NuriVoice STT 초안.lnk`를 더블클릭하세요.**

창에서 **영어 / 프랑스어 / 한국어 예제 실행**을 누르면 포함된 공개 음성을 실제로 인식합니다. 직접 준비한 파일은 **WAV 선택 → 파일 인식 시작**으로 처리합니다. 인식 문장 복사, JSON 저장, 입력 음성 재생, 중지를 제공합니다.

마이크는 **마이크로 녹음** 버튼을 누른 뒤 확인해야 시작합니다. 일반 전사 5초, 프랑스어 스트리밍 10초입니다. 자동 녹음과 외부 전송은 없습니다.

드라이브 이동으로 바로가기가 작동하지 않으면 같은 폴더의 `NuriVoice_STT.vbs`를 실행하세요. 실행 위치에서 포터블 Python 경로를 계산합니다. `.venv` 복구가 필요하면 `scripts/setup_environment.ps1`을 사용합니다.

실제 화면: [desktop_preview.png](reports/desktop_preview.png). UI·실행기 검증: [DESKTOP_DRAFT_REPORT.md](reports/DESKTOP_DRAFT_REPORT.md).

독립 로컬 Python SDK/CLI. 14/17 프로젝트를 실행 중 참조하지 않으며 `models/` 사본으로 실행한다. 공개 가중치의 소유권은 원저작자에게 있다. 프로젝트 내부 `.venv` 격리 환경과 소스 직접 실행을 제공한다. `requirements-lock.txt`는 검증 환경 버전이다. 최신 납품·실측은 [최종 결과서](reports/FINAL_IMPLEMENTATION_REPORT.md)에 모았다.

프로젝트 폴더에서 격리 환경 실행:

```powershell
.\scripts\run_isolated.ps1 transcribe --input .\datasets\librispeech_1272_128104_0000.wav --language auto --model auto
```

다른 PC 또는 드라이브로 옮기면 먼저 `scripts/setup_environment.ps1`로 환경을 재생성한다. 설치 시 공식 PyPI 무료 의존성을 프로젝트 내부에 설치하며 모델 전사 실행에는 네트워크가 필요 없다.

워크스페이스 루트에서:

```powershell
& '.\03. Program\Python\python.exe' -B '.\02. Apps\18. NuriVoice_STT_Engine_Design\scripts\run.py' transcribe --input '.\02. Apps\18. NuriVoice_STT_Engine_Design\datasets\librispeech_1272_128104_0000.wav' --language en --model tiny
& '.\03. Program\Python\python.exe' -B '.\02. Apps\18. NuriVoice_STT_Engine_Design\scripts\run.py' phoneme --input 'sample.wav' --l1 ko --l2 fr --target a
& '.\03. Program\Python\python.exe' -B '.\02. Apps\18. NuriVoice_STT_Engine_Design\scripts\run.py' transcribe --mic --language ko
& '.\03. Program\Python\python.exe' -B '.\02. Apps\18. NuriVoice_STT_Engine_Design\scripts\record_sample.py' --consent --label a --speaker s01 --l1 ko --l2 fr --target a
```

`--mic` 명시 실행만 일반 전사 5초, streaming 10초 녹음을 시작한다. 라벨링 도구와 streaming JSONL 도구는 Enter 확인 후 녹음한다. 자동녹음·원격 업로드 없음. 장치·권한 오류는 WAV 입력으로 대체한다. API는 `src`를 Python 경로에 추가한 뒤 `from nurivoice_stt import recognize; recognize('sample.wav', language='fr')`.

WAV 최대120초·mono 변환·16kHz 정규화. FLAC은 benchmark 스크립트에서 WAV로 변환한다. 언어 11개·locale 23개를 설정할 수 있고 11개 언어 실제 사람 문장 전사를 실행했다. locale는 언어 일치 검사를 거치는 지역 메타데이터이며 방언별 정확도를 보증하지 않는다. 음소는 프랑스어 모음 후보를 실험적으로 지원한다. L1은 경쟁 후보 힌트이며 점수 가산 없음. `phone_match=null`, `validated=false`는 지시서의 검증 전 계약이다. 발음 평가는 별도 assessment 계층에서 unsupported/unvalidated를 반환한다.

`--language auto`는 실제 Whisper 언어식별을 실행한다. `--model auto`는 balanced/low_memory에서 tiny, quality에서 base를 선택한다. balanced 자동 선택에서 tiny가 지원 밖 언어를 판별하면 base로 재판별하며 이력은 JSON에 남긴다. low_memory는 추가 모델 로드를 피한다. 잘못된 언어식별은 가능하므로 언어를 아는 경우 명시할 수 있다.

검증: `tests/test_contract.py`, `tests/test_evaluator.py`, `scripts/benchmark_alpha.py`. 현재 버전은 단일 모델 세션을 재사용하며 `timing.model_load_ms`, `timing.inference_ms`, `integrity_ms`를 분리한다. API latency를 순수 추론 지연으로 해석하지 않는다. 결과와 한계: `reports/FINAL_IMPLEMENTATION_REPORT.md` 및 `reports/CONTINUATION_IMPLEMENTATION_REPORT.md`.

## 후속 구현: VAD·스트리밍·독립 설치

`transcribe --vad --trim`은 Silero VAD와 앞뒤 무음 제거를 선택 적용한다. 단독 음소에 검증된 기본값은 아니며 기본 off다.

`streaming --input french.wav --language fr`는 프랑스어 Zipformer 파일 청크 스트리밍 결과와 부분결과 목록을 공통 JSON으로 반환한다. `streaming --mic --language fr`는 실제 마이크 청크를 online recognizer로 전달한다. JSONL 부분결과를 즉시 받으려면 `scripts/stream_file.py --mic --consent`를 사용한다. 파일 fast-feed 지연과 live microphone 지연은 구별한다. 실제 장치 녹음은 사용자의 명시 조작으로 시험한다.

`scripts/doctor.py`는 모델 해시·패키지·마이크 존재만 진단하며 녹음하지 않는다. `scripts/evaluate_labeled.py --manifest datasets/recorded/labels.csv --output benchmarks/my_eval.json`은 동의·원음 SHA·화자 split 검증 후 음소 비교한다. 출력 경로는 프로젝트 내부이며 기존 결과를 덮어쓰지 않는다.

SDK를 editable/wheel 환경에서 사용할 때 `NURIVOICE_HOME`을 이 프로젝트의 절대 경로로 설정하면 models/와 third_party/를 찾는다. `scripts/sdk_example.py input.wav`는 별도 앱 연동 예제다. 격리 환경 설치·빌드 검증은 reports/의 환경 검증 기록을 따른다.

LibriSpeech 1문장, FLEURS 프랑스어3/한국어3 및 나머지9개 언어 각1문장으로 실행했다. 언어별 실행 결과와 오류는 datasets/public_multilingual/RESULTS.md 및 datasets/language_coverage/README.md에 공개한다. 실제 사람 단독 모음 정확도는 아직 NOT_MEASURED이며, 수집·라벨링·평가 코드는 제공한다.
