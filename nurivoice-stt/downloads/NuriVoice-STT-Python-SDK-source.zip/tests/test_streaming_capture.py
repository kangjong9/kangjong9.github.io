"""마이크 실제 녹음 없이 consent/장치오류/취소/청크 상태와 공개 WAV paced 흐름 검증."""
import sys
from pathlib import Path
import threading
import time
import unittest
from unittest.mock import patch
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from nurivoice_stt.capture import microphone_chunks,read_wav
from nurivoice_stt.streaming import FrenchStreaming


class StreamingCaptureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.engine=FrenchStreaming()

    def test_consent_does_not_probe_device(self):
        with patch('nurivoice_stt.capture.microphone_diagnostics') as probe:
            with self.assertRaises(PermissionError):next(microphone_chunks())
            probe.assert_not_called()

    def test_no_device_diagnostic(self):
        with patch('nurivoice_stt.capture.microphone_diagnostics',return_value={'available':False}):
            with self.assertRaises(RuntimeError):next(microphone_chunks(consent=True))

    def test_pre_cancel_never_opens(self):
        cancel=threading.Event();cancel.set()
        with patch('nurivoice_stt.capture.microphone_diagnostics') as probe:
            self.assertEqual(list(microphone_chunks(consent=True,cancel=cancel)),[])
            probe.assert_not_called()

    def test_mock_capture_cancel_and_close(self):
        closed=[];cancel=threading.Event()
        def chunks():
            try:
                yield np.zeros(2560,np.float32)
                cancel.set()
                yield np.zeros(2560,np.float32)
            finally:closed.append(True)
        with patch('nurivoice_stt.capture.microphone_chunks',return_value=chunks()):
            events=list(self.engine.stream_microphone(consent=True,cancel=cancel))
        self.assertEqual(events[-1]['status'],'cancelled')
        self.assertTrue(closed)

    def test_capture_timeout_propagates(self):
        def chunks():
            raise TimeoutError('mock capture timeout')
            yield
        with patch('nurivoice_stt.capture.microphone_chunks',return_value=chunks()):
            with self.assertRaises(TimeoutError):list(self.engine.stream_microphone(consent=True))

    def test_real_public_wav_paced_chunks(self):
        x=read_wav(ROOT/'datasets/public_multilingual/fr_fr_10043298898524273336_pcm16.wav')
        def paced():
            started=time.monotonic()
            for i in range(0,len(x),2560):
                end=min(i+2560,len(x))
                time.sleep(max(0,started+end/16000-time.monotonic()))
                yield x[i:end]
        events=list(self.engine.stream_chunks(paced(),feed_mode='paced public WAV; not microphone'))
        self.assertTrue(any(e['status']=='partial' for e in events))
        self.assertEqual(events[-1]['status'],'recognized')
        self.assertAlmostEqual(events[-1]['audio_received_seconds'],len(x)/16000)
        self.assertGreaterEqual(events[-1]['runtime_ms'],10000)


if __name__=='__main__':unittest.main(verbosity=2)
