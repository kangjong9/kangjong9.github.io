"""라벨·동의·원음 경계를 검증하며 실제 녹음/모델 추론을 하지 않는다."""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

P=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('evaluate_labeled',P/'scripts/evaluate_labeled.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class EvaluatorTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=P/'tests',prefix='labels_')
        self.addCleanup(self.temp.cleanup)
        self.folder=Path(self.temp.name)
        self.sample=self.folder/'fake.wav'
        self.sample.write_bytes(b'not opened by model in this mocked contract test')
        self.row=dict(sample_id='synthetic_contract',path='fake.wav',speaker='synthetic',split='dev',
                      label='i',target='a',l1='ko',l2='fr',locale='fr-FR',rights=module.CONSENT,
                      sha256=hashlib.sha256(self.sample.read_bytes()).hexdigest())

    def run_manifest(self, rows):
        manifest=self.folder/'labels.csv'
        with manifest.open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=self.row.keys()); w.writeheader(); w.writerows(rows)
        output=self.folder/'result.json'
        with patch.object(sys,'argv',['evaluate','--manifest',str(manifest),'--output',str(output)]), \
             patch.object(module,'recognize',return_value={'status':'unknown'}) as call, patch('builtins.print'):
            module.main()
        return json.loads(output.read_text(encoding='utf-8')),call

    def test_recorder_schema_produces_four_separate_variants(self):
        result,call=self.run_manifest([self.row])
        self.assertEqual(len(result['results']),4)
        self.assertEqual(call.call_count,4)
        self.assertEqual(call.call_args.kwargs['locale'],'fr-FR')
        self.assertEqual(result['results'][0]['reference'],'i')

    def test_missing_consent_prevents_sample_inference(self):
        self.row['rights']=''
        result,call=self.run_manifest([self.row])
        self.assertEqual(result['results'][0]['status'],'HOLD')
        call.assert_not_called()

    def test_hash_mismatch_prevents_inference(self):
        self.row['sha256']='0'*64
        result,call=self.run_manifest([self.row])
        self.assertEqual(result['results'][0]['reason'],'sample hash mismatch')
        call.assert_not_called()

    def test_speaker_split_leakage_rejected(self):
        other=dict(self.row,split='test')
        with self.assertRaisesRegex(ValueError,'split'):
            self.run_manifest([self.row,other])

    def test_external_manifest_rejected_before_open(self):
        with self.assertRaises(ValueError): module.safe_project_path(P.parent/'not_allowed.csv')

    def test_protected_folder_name_rejected_before_access(self):
        with self.assertRaises(ValueError): module.safe_project_path(P/'GC업무'/'sample.wav')

if __name__=='__main__': unittest.main(verbosity=2)
