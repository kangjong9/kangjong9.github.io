"""Mocked control-flow regression, distinct from real language accuracy."""
import sys
import unittest
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from nurivoice_stt.api import recognize


class LanguageDetectionTests(unittest.TestCase):
    def run_auto(self, detected, model='tiny', **kwargs):
        with ExitStack() as stack:
            stack.enter_context(patch('nurivoice_stt.api.read_wav', return_value=np.ones(16000, dtype=np.float32)))
            stack.enter_context(patch('nurivoice_stt.api.inspect_audio', return_value=None))
            stack.enter_context(patch('nurivoice_stt.registry.verify_models'))
            stack.enter_context(patch('pathlib.Path.read_bytes', return_value=b'mocked-model'))
            detector = stack.enter_context(patch('nurivoice_stt.adapters.identify_language', side_effect=detected if isinstance(detected, list) else None, return_value=detected))
            transcribe = stack.enter_context(patch('nurivoice_stt.adapters.transcribe', return_value='bonjour'))
            result = recognize('mock.wav', language='auto', model=model, **kwargs)
            self.detector_calls = detector.call_args_list
            return result, transcribe.call_args_list

    def test_supported_detected_language_drives_transcription(self):
        result, calls = self.run_auto('fr')
        self.assertEqual(result['status'], 'recognized')
        self.assertEqual(result['language'], 'fr')
        self.assertEqual(calls[0].args[1:], ('fr', 'tiny'))
        self.assertFalse(result['language_detection']['validated'])

    def test_unsupported_detected_language_blocks_transcription(self):
        result, calls = self.run_auto('ar')
        self.assertEqual(result['status'], 'unsupported')
        self.assertEqual(result['reject_reason'], 'detected_language_unsupported')
        self.assertFalse(calls)

    def test_locale_mismatch_blocks_transcription(self):
        result, calls = self.run_auto('fr', locale='ko-KR')
        self.assertEqual(result['reject_reason'], 'detected_language_locale_mismatch')
        self.assertEqual(result['status'], 'unsupported')
        self.assertFalse(calls)

    def test_bokmal_locale_matches_no(self):
        result, calls = self.run_auto('no', locale='nb-NO')
        self.assertEqual(result['status'], 'recognized')
        self.assertTrue(calls)

    def test_auto_policy_retries_base_and_preserves_attempt(self):
        result, calls = self.run_auto(['sv', 'no'], model='auto')
        self.assertEqual(result['status'], 'recognized')
        self.assertEqual(result['language'], 'no')
        self.assertEqual(calls[0].args[1:], ('no', 'base'))
        self.assertEqual([call.args[1] for call in self.detector_calls], ['tiny', 'base'])
        self.assertEqual(result['language_detection']['previous_attempt']['language'], 'sv')
        self.assertIn('retry base', result['route']['reason'])

    def test_low_memory_does_not_load_base(self):
        result, calls = self.run_auto(['sv', 'no'], model='auto', device_profile='low_memory')
        self.assertEqual(result['status'], 'unsupported')
        self.assertEqual(len(self.detector_calls), 1)
        self.assertFalse(calls)

    def test_both_unsupported_never_invent_supported_language(self):
        result, calls = self.run_auto(['sv', 'ar'], model='auto')
        self.assertEqual(result['status'], 'unsupported')
        self.assertEqual(result['language'], 'ar')
        self.assertEqual(result['reject_reason'], 'detected_language_unsupported')
        self.assertIsNone(result['transcript'])
        self.assertEqual(len(self.detector_calls), 2)
        self.assertFalse(calls)

    def test_explicit_tiny_does_not_retry(self):
        result, calls = self.run_auto(['sv', 'no'], model='tiny')
        self.assertEqual(result['status'], 'unsupported')
        self.assertEqual(len(self.detector_calls), 1)
        self.assertFalse(calls)


if __name__ == '__main__':
    unittest.main()
