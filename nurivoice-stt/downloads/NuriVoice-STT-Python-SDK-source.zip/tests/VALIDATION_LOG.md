# Contract and packaging validation — 2026-10-30

Command from workspace root:

```powershell
& '.\03. Program\Python\python.exe' -B '.\02. Apps\18. NuriVoice_STT_Engine_Design\tests\test_contract.py'
```

Latest run: 23 tests, 0.377 seconds, OK. These are API/error/heuristic/contract tests and deterministic synthetic controls, not recognition accuracy measurements. Cache factory is mocked; no model timing claim follows from that test.

Coverage: required JSON fields and serialization; no implicit recording; explicit microphone consent; mocked missing device diagnosis; CLI input exclusivity and argument forwarding; inconsistent locale rejection; missing/malformed input; short input; silence/noise forced-success prevention; nonfinite input; immutable input; unsupported assessment; target/language routing; Korean L1 competitor hint; mixed phone sequence rejection; cache reuse and invalidation after changed model size.

Temporary synthetic test WAVs were created only under tests/ and removed by TemporaryDirectory cleanup. No actual microphone recording was started. No original 14/17 files were changed.

Doctor command: `python -B scripts/doctor.py`. Actual result: all five required packages found; tiny/base/phoneme hashes verified; WinMM reports one device and recording_started=false. Device count does not prove capture permission or successful recording. TOML parse and doctor syntax compile passed. Wheel build/install was not tested; current package configuration supports source/editable use while model-root deployment remains a packaging limitation.

Benchmark review corrections: runtime/input failures now have null WER/CER and a separate NOT_MEASURED status; successful empty hypotheses remain measurable ASR failure. New benchmark runs use timestamped subdirectories and preserve previous baseline results. Full performance rerun awaits exclusive CPU measurement opportunity from root.

Remaining review considerations: registry hash verification is performed before API inference; cache signature uses size/mtime (not adversarial same-size/same-mtime tamper detection). A model revision field representing only encoder hash does not fully identify decoder/tokenizer; manifest remains the authoritative full-artifact record. ZCR rejection is a heuristic, not a calibrated VAD. Mixed-duration or concurrent-load timing requires explicit reporting.

## Labeled evaluator follow-up

`python -B tests/test_evaluator.py`: six tests passed in 0.111 seconds. Inference is mocked; no user recording is opened. Tests cover recorder CSV compatibility with four ablation rows, consent rejection, SHA mismatch rejection, speaker split leakage, external manifest path rejection, and forbidden folder rejection before access. Evaluator now validates manifest and sample paths before opening, rejects links/junctions and boundary escape, forwards locale, requires explicit target/label metadata, preserves sample ID, and uses exclusive output creation. No arbitrary target or language default is substituted for missing labels. Four variants of one sample are not four independent observations.

## Isolated environment validation
43 tests PASS in 11.709 s with project .venv; public wheel transcription recognized; all14 source modules byte-match installed wheel. See reports/ISOLATED_ENVIRONMENT_VALIDATION.md and isolated_wheel_smoke.json.
