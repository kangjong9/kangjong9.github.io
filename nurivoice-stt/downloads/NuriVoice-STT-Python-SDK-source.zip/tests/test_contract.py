"""Alpha public API regression checks; synthetic controls are not speech accuracy data."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
import wave
from unittest.mock import patch

import numpy as np

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / 'src'))
from nurivoice_stt.api import recognize
from nurivoice_stt.phoneme import decide
from nurivoice_stt.quality import inspect_audio
from nurivoice_stt.capture import record_microphone
from nurivoice_stt import adapters

FIELDS = {'status', 'task', 'transcript', 'phone_hypotheses', 'target_phone',
          'phone_match', 'reject_reason', 'language', 'locale', 'l1',
          'model_id', 'model_revision', 'runtime_ms', 'score_type', 'validated'}


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='contract_', dir=PROJECT / 'tests')
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)

    def wav(self, name, audio, rate=16000):
        path = self.folder / name
        with wave.open(str(path), 'wb') as stream:
            stream.setnchannels(1)
            stream.setsampwidth(2)
            stream.setframerate(rate)
            stream.writeframes((np.asarray(audio).clip(-1, 1) * 32767).astype('<i2').tobytes())
        return path

    def contract(self, result):
        self.assertIsInstance(result, dict)
        self.assertFalse(FIELDS - result.keys(), FIELDS - result.keys())
        json.dumps(result, ensure_ascii=False, allow_nan=False)
        self.assertGreaterEqual(result['runtime_ms'], 0)

    def test_silence_never_transcribes(self):
        result = recognize(self.wav('silence.wav', np.zeros(16000)), language='fr')
        self.contract(result)
        self.assertNotEqual(result['status'], 'recognized')
        self.assertFalse(result['transcript'])

    def test_silence_never_matches_requested_phone(self):
        path = self.wav('silence.wav', np.zeros(16000))
        for target in ['a', 'i', 'u', 'ɛ']:
            with self.subTest(target=target):
                result = recognize(path, task='phoneme', language='fr', l1='ko', target=target)
                self.contract(result)
                self.assertIsNot(result['phone_match'], True)
                self.assertFalse(result['validated'])
                self.assertNotEqual(result['status'], 'recognized')

    def test_short_audio_has_explicit_non_success(self):
        path = self.wav('short.wav', np.ones(80) * .01)
        result = recognize(path, task='phoneme', language='fr', target='a')
        self.contract(result)
        self.assertNotEqual(result['status'], 'recognized')
        self.assertTrue(result['reject_reason'])

    def test_missing_input_returns_json_error(self):
        result = recognize(self.folder / 'missing.wav')
        self.contract(result)
        self.assertEqual(result['status'], 'error')

    def test_malformed_wav_returns_json_error(self):
        path = self.folder / 'bad.wav'
        path.write_bytes(b'not a wave file')
        result = recognize(path)
        self.contract(result)
        self.assertEqual(result['status'], 'error')

    def test_assessment_does_not_claim_validated_grade(self):
        result = recognize(self.wav('assessment.wav', np.zeros(16000)), task='assessment', language='fr')
        self.contract(result)
        self.assertFalse(result['validated'])
        self.assertIsNone(result['phone_match'])
        self.assertNotEqual(result['status'], 'recognized')

    def test_unsupported_language_not_silent_fallback(self):
        result = recognize(self.wav('lang.wav', np.zeros(16000)), language='zz')
        self.contract(result)
        self.assertNotEqual(result['status'], 'recognized')
        self.assertTrue(result['reject_reason'])

    def test_input_is_unchanged(self):
        path = self.wav('immutable.wav', np.zeros(16000))
        original = path.read_bytes()
        recognize(path, task='phoneme', language='fr', target='a')
        self.assertEqual(path.read_bytes(), original)

    def test_target_inside_word_is_not_isolated_phone(self):
        self.assertEqual(decide(['b', 'a'], 'fr', 'a')[0], 'rejected')
        self.assertEqual(decide(['i'], 'fr', 'a')[0], 'rejected')

    def test_empty_output_does_not_force_target(self):
        self.assertEqual(decide([], 'fr', 'a')[0], 'unknown')

    def test_target_selection_changes_decision(self):
        self.assertEqual(decide(['i'], 'fr', 'i')[0], 'recognized')
        self.assertEqual(decide(['i'], 'fr', 'a')[0], 'rejected')

    def test_language_and_target_capability(self):
        self.assertEqual(decide(['a'], 'zh', 'a')[0], 'unsupported')
        self.assertEqual(decide(['a'], 'fr', 'not-a-phone')[0], 'unsupported')

    def test_l1_hint_changes_competitors_not_success(self):
        plain = decide(['ɯ'], 'fr', 'u')
        hinted = decide(['ɯ'], 'fr', 'u', 'ko')
        self.assertNotIn('ɯ', plain[2])
        self.assertIn('ɯ', hinted[2])
        self.assertEqual(plain[0], 'rejected')
        self.assertEqual(hinted[0], 'rejected')

    def test_nonfinite_input_is_not_valid_signal(self):
        self.assertEqual(inspect_audio(np.full(16000, np.nan)), 'invalid_audio')

    def test_seeded_noise_cannot_force_success(self):
        audio = np.random.default_rng(20261030).normal(0, .03, 16000)
        result = recognize(self.wav('noise.wav', audio), task='phoneme', language='fr', target='a')
        self.contract(result)
        self.assertNotEqual(result['status'], 'recognized')
        self.assertIsNot(result['phone_match'], True)

    def test_recording_requires_explicit_consent(self):
        with self.assertRaises(PermissionError):
            record_microphone(consent=False)

    def test_missing_microphone_is_diagnosed_without_recording(self):
        with patch('nurivoice_stt.capture.microphone_diagnostics', return_value={'available': False}):
            with self.assertRaisesRegex(RuntimeError, 'WAV|audio.wav'):
                record_microphone(consent=True)

    def test_no_input_does_not_implicitly_record(self):
        with patch('nurivoice_stt.capture.record_microphone') as record:
            result = recognize(None)
            self.assertEqual(result['status'], 'error')
            record.assert_not_called()

    def test_cli_mutually_exclusive_input_never_calls_recognizer(self):
        from nurivoice_stt import cli
        with patch.object(sys, 'argv', ['nurivoice-stt', 'transcribe', '--mic', '--input', 'dummy.wav']), \
             patch.object(cli, 'recognize') as call, patch('sys.stderr'):
            with self.assertRaises(SystemExit) as exc:
                cli.main()
            self.assertEqual(exc.exception.code, 2)
            call.assert_not_called()

    def test_cli_language_and_locale_are_forwarded(self):
        from nurivoice_stt import cli
        with patch.object(sys, 'argv', ['nurivoice-stt', 'phoneme', '--input', 'dummy.wav',
                                      '--l2', 'fr', '--locale', 'fr-CA', '--l1', 'ko', '--target', 'u']), \
             patch.object(cli, 'recognize', return_value={'status': 'unknown'}) as call, patch('builtins.print'):
            self.assertEqual(cli.main(), 0)
            args = call.call_args.args
            self.assertEqual(args[2:6], ('fr', 'fr-CA', 'ko', 'u'))

    def test_inconsistent_locale_is_rejected(self):
        result = recognize(self.folder/'unused.wav', language='fr', locale='en-US')
        self.contract(result)
        self.assertEqual(result['status'], 'unsupported')
        self.assertEqual(result['reject_reason'], 'unsupported_locale')

    def test_api_input_and_microphone_conflict_never_records(self):
        with patch('nurivoice_stt.capture.record_microphone') as record:
            result = recognize(self.folder/'unused.wav', mic=True)
            self.assertEqual(result['status'], 'error')
            record.assert_not_called()

    def test_cache_reuses_then_invalidates_changed_model(self):
        model_file = self.folder/'model.onnx'
        model_file.write_bytes(b'first')
        made=[]
        def factory():
            instance=object()
            made.append(instance)
            return instance
        adapters.clear_cache()
        self.addCleanup(adapters.clear_cache)
        with patch.object(adapters, 'MODELS', self.folder):
            first=adapters._get(('test',), factory)
            self.assertFalse(adapters.metrics()['cache_hit'])
            second=adapters._get(('test',), factory)
            self.assertIs(first, second)
            self.assertTrue(adapters.metrics()['cache_hit'])
            model_file.write_bytes(b'changed-size')
            third=adapters._get(('test',), factory)
            self.assertIsNot(third, first)
            self.assertFalse(adapters.metrics()['cache_hit'])
        self.assertEqual(len(made), 2)


if __name__ == '__main__':
    unittest.main(verbosity=2)
