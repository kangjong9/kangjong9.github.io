"""실제 GUI 자식 프로세스와 UTF-8 pipe 경계 회귀. 마이크 실행 없음."""
import json
from pathlib import Path
import subprocess
import unittest

ROOT=Path(__file__).resolve().parents[1]

class DesktopWorkerTests(unittest.TestCase):
    def call(self, **overrides):
        request=dict(path=str(ROOT/'datasets/librispeech_1272_128104_0000.wav'),
                     task='transcribe',language='en',model='tiny',mic=False,l1=None,target=None)
        request.update(overrides)
        result=subprocess.run([str(ROOT/'.venv/Scripts/python.exe'),'-B',str(ROOT/'scripts/desktop.pyw'),'--worker'],
            input=json.dumps(request,ensure_ascii=False)+'\n',capture_output=True,text=True,encoding='utf-8',
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),timeout=45)
        self.assertEqual(result.returncode,0,result.stderr)
        return json.loads(result.stdout)

    def test_real_audio_korean_path_utf8_pipe(self):
        result=self.call()
        self.assertEqual(result['status'],'recognized')
        self.assertIn('Quilter',result['transcript'])

    def test_missing_file_is_json_error(self):
        result=self.call(path=str(ROOT/'없는_파일.wav'))
        self.assertEqual(result['status'],'error')
        self.assertTrue(result['error'])

    def test_unsupported_language_is_not_fake_success(self):
        self.assertEqual(self.call(language='invalid')['status'],'unsupported')

if __name__=='__main__': unittest.main(verbosity=2)
