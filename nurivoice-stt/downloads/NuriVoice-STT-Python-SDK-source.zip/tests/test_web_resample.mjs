import assert from 'node:assert/strict';
import {PCMResampler} from '../web/resample.js';
import {writeFileSync} from 'node:fs';

function run(audio, rate, sizes) {
  const r = new PCMResampler(rate), chunks = [];
  let start = 0, n = 0;
  while (start < audio.length) {
    const end = Math.min(audio.length, start + sizes[n++ % sizes.length]);
    chunks.push(...r.push([audio.subarray(start,end)])); start = end;
  }
  chunks.push(...r.flush());
  assert.deepEqual(r.flush(), []);
  const data = new Float32Array(chunks.reduce((sum,c) => sum+c.length,0));
  let at = 0;
  chunks.forEach((c,i) => { assert.ok(c.length <= 2560); if(i<chunks.length-1) assert.equal(c.length,2560); data.set(c,at);at+=c.length; });
  return {data,chunkLengths:chunks.map(c=>c.length)};
}
const rows=[];
for (const rate of [44100,48000,16000]) {
  for (const length of [1,127,128,129,rate,rate*2+17]) {
    const audio = Float32Array.from({length},(_,i)=>.5*Math.sin(2*Math.PI*440*i/rate));
    const whole=run(audio,rate,[length]);
    const split=run(audio,rate,[128]);
    const irregular=run(audio,rate,[1,17,253,3,128]);
    assert.deepEqual(split.data,whole.data);
    assert.deepEqual(irregular.data,whole.data);
    assert.equal(split.data.length,Math.ceil(length*16000/rate));
    let square=0;
    // Exclude final held endpoint from the interpolation fidelity observation.
    for(let i=0;i<split.data.length-1;i++) square+=(split.data[i]-.5*Math.sin(2*Math.PI*440*i/16000))**2;
    const rms=Math.sqrt(square/Math.max(1,split.data.length-1));
    assert.ok(rms<.002);
    rows.push({rate,input_frames:length,output_samples:split.data.length,split_exact:true,sine_440hz_rms_error:rms,chunk_lengths:split.chunkLengths});
  }
}
const stereo=new PCMResampler(16000);
assert.deepEqual(stereo.push([Float32Array.of(1,-1),Float32Array.of(-1,1)]),[]);
assert.deepEqual([...stereo.flush()[0]],[0,0]);
const empty=new PCMResampler(48000);assert.deepEqual(empty.flush(),[]);
assert.throws(()=>empty.push([Float32Array.of(0)]));

// Worklet adapter runs against a minimal offline host, never getUserMedia.
let Processor;
globalThis.sampleRate=48000;
globalThis.AudioWorkletProcessor=class {constructor(){this.messages=[];this.port={postMessage:(data,transfer)=>this.messages.push({data,transfer})};}};
globalThis.registerProcessor=(name,klass)=>{assert.equal(name,'pcm-capture');Processor=klass;};
await import('../web/pcm-capture.js');
const processor=new Processor(), output=[new Float32Array(128).fill(1)];
for(let i=0;i<60;i++) assert.equal(processor.process([[new Float32Array(128).fill(.25)]],[output]),true);
assert.ok(output[0].every(x=>x===0));
processor.port.onmessage({data:{type:'flush'}});
const messages=processor.messages;
assert.equal(messages[0].data.audio.length,2560);
assert.equal(messages[0].transfer[0],messages[0].data.audio.buffer);
assert.equal(messages.at(-1).data.type,'flushed');
assert.equal(messages.at(-1).data.output_samples,2560);
assert.equal(processor.process([],[]),false);
writeFileSync(new URL('../reports/web_resample_test.json',import.meta.url),JSON.stringify({status:'PASS',rows,
  worklet_mock:{silence_output:true,transfer_list:true,flush_ack:true},
  scope:'Offline synthetic 440Hz sine and mock AudioWorklet host; no microphone access. Linear interpolation has no anti-alias low-pass filter. Physical browser AudioWorklet device timing not tested.'},null,2));
console.log('PASS: 18 duration/split/sine cases, stereo mixing, empty/flush lifecycle, worklet mock silence and transferable chunks');
