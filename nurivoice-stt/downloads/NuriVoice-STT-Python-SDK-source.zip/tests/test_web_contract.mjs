import assert from 'node:assert/strict';
import {decidePhones, collapseCTC, recognizePhones, disposePhones} from '../web/phoneme.js';
import {segmentsFromProbabilities, detectSpeech, disposeVAD} from '../web/vad.js';

assert.equal(decidePhones([], 'fr', 'a').status, 'unknown');
assert.equal(decidePhones(['b','a'], 'fr', 'a').status, 'rejected');
assert.equal(decidePhones(['a'], 'fr', 'a').status, 'recognized');
assert.equal(decidePhones(['a'], 'fr', 'i').status, 'rejected');
assert.equal(decidePhones(['a'], 'en', 'a').status, 'unsupported');
assert.ok(decidePhones(['u'], 'fr', 'u', 'ko').competitors.includes('ɯ'));
assert.ok(!decidePhones(['u'], 'fr', 'u', 'en').competitors.includes('ɯ'));
const ctc = collapseCTC(Float32Array.of(0,9,1, 0,8,1, 9,0,1, 0,8,1),4,3,{0:'_',1:'a',2:'i'});
assert.deepEqual(ctc.phones,['a','a']); // Blank separates identical phones.
assert.equal(ctc.scores.a, 6.25);
assert.deepEqual(segmentsFromProbabilities([0,0],1024),[]);
assert.deepEqual(segmentsFromProbabilities([.9,.9],1024),[{start:0,end:1024}]);
assert.deepEqual(segmentsFromProbabilities([.9,0,0,0,0,0,0],3584,{paddingMs:0}),[{start:0,end:512}]);
const unsupported = await recognizePhones(new Float32Array(0),{language:'en',target:'a'});
assert.equal(unsupported.status,'unsupported');
assert.equal(unsupported.phone_match,null);
assert.equal(unsupported.validated,false);
assert.equal((await recognizePhones(Float32Array.of(NaN),{target:'a'})).status,'error');
assert.deepEqual(await detectSpeech(new Float32Array(0)),[]);
await assert.rejects(detectSpeech(Float32Array.of(Infinity)));
await disposePhones(); await disposeVAD();
console.log('17 browser-module contract assertions passed; no model/network/microphone use');
