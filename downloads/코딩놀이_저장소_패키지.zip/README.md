# 🎮 코딩놀이터 (Coding Playground) 공식 프로젝트 저장소 패키지

> **"겉보기엔 멀쩡한 어른, 정신연령은 호기심 가득한 유딩! 철들 틈 없이 바쁜 주인아저씨와 AI 친구들의 코딩 놀이터"**

---

## 🌟 1. 프로젝트 개요
**코딩놀이터**는 가변형 포터블 환경을 기반으로 인간 개발자와 3대 최첨단 AI 에이전트(AGY · CODEX · Claude)가 실시간으로 입체 협업하여 창작하는 소프트웨어 놀이방입니다.

- **공식 홈페이지**: https://kangjong9.github.io/
- **공식 GitHub 저장소**: https://github.com/kangjong9
- **개발 환경**: Windows 포터블 가변형 외장하드 시스템 (Python, C/C++, Java, Android, Web)

---

## 📱 2. 주요 작업물 (Work Showcase)

### 🌸 귀염뽀짝 가계부 (CuteLedger)
- **플랫폼**: Android 모바일 (APK) & Windows 데스크톱 (PC)
- **특징**: 국내 15개 카드사·은행 결제 SMS/푸시 자동 파싱, 자산 연동 복식부기, Gemini AI 영수증 인식, 귀염뽀짝 위젯.

### 🏃‍♀️ 맹맹 다이어트 작전 (MaengDiet)
- **플랫폼**: Android 모바일 (APK) & Windows 데스크톱 (PC)
- **특징**: 3중 센서 퓨전 만보기, Health Connect 연동, Gemini 음식 칼로리 비전 추정, 스마트 식단 캘린더.

### 🧹 찌꺼기저리가 (Cleaner)
- **플랫폼**: Windows 데스크톱 (PC)
- **특징**: 개발 임시 파일, 브라우저 캐시, 시스템 찌꺼기 1클릭 고속 정리 도구.

### 🏢 AI 친구들과 함께 실시간 회의실 & 내역서 마스터
- 인간 개발자와 AI 삼총사가 실시간으로 소통하며 코드를 진단하고 설계하는 지능형 오케스트레이션 플랫폼.

---

## 📂 3. 패키지 구성품 안내
1. `README.md`: 프로젝트 및 생태계 공식 소개 문서 (본 파일)
2. `구글_무료배포_가이드_사용자용.pdf`: 안드로이드 지인 무료 앱 설치 및 기기 승인 4단계 완벽 매뉴얼 (시인성 극대화 v4)
3. `코딩놀이터_홈페이지_바로가기.url`: kangjong9 개인 홈페이지 원클릭 접속
4. `코딩놀이터_GitHub_저장소_바로가기.url`: 공식 GitHub 저장소 원클릭 접속

---
© 2026 Coding Playground (kangjong9). All rights reserved.
